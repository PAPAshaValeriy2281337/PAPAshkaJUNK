public class DialogFragment extends Fragment{
    public DialogFragment(int LayoutType, int FragmentWidth, int FragmentHeigth, int ColumnsCount, int LinesCount, String TextColor, String BackgroundColor){
        super(LayoutType, FragmentWidth, FragmentHeigth, ColumnsCount, LinesCount, TextColor, BackgroundColor);
    }
}